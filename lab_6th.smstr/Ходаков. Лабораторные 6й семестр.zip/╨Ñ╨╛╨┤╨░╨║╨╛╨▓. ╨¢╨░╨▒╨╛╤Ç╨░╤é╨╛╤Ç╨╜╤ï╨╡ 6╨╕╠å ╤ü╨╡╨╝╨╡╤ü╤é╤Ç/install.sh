#!/bin/bash

composer update
php yii migrate