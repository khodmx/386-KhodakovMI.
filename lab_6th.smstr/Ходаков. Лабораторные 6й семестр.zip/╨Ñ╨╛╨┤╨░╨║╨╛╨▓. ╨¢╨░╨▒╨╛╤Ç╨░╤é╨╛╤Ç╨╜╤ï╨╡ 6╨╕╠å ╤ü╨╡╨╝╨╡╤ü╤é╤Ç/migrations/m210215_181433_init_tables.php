<?php

use yii\db\Migration;

/**
 * Class m210215_181433_init_tables
 */
class m210215_181433_init_tables extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('comment', [
            'comment_id' => $this->integer()->notNull(),
            'username' => $this->string()->defaultValue(null),
            'content' => $this->text()->defaultValue(null),
            'product_id' => $this->integer()
        ]);

        $this->createTable('product', [
            'product_id' => $this->integer()->notNull(),
            'title' => $this->string()->defaultValue(null),
            'description' => $this->text()->defaultValue(null)
        ]);

        $this->createIndex(
            'idx-comment-product',
            'comment',
            'product_id'
        );

        $this->addForeignKey(
            'comment_ibfk_1',
            'comment',
            'product_id',
            'product',
            'product_id'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m210215_181433_init_tables cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210215_181433_init_tables cannot be reverted.\n";

        return false;
    }
    */
}
