<?php
include "VarDumper.php";

class Wolf {

    public $paws = 4;
    public $head = 1;
    public $fingers = 10;
    public $arms = 0;
    public $steps = 0;

    public function addPaws() {

        $this->hands++;
    }
    public function say($text) {

        echo $text;
    }
    public function go(){
        if ($this->steps != 0 ){
            return $this->steps++;
        }
    }
    public function jump(){
        $this->paws--;
    }
    public function fall() {

        $this->health--;
    }
    public function eat() {
    if ($this->hunger <= 75){
    return $this->hunger = $this->hunger+25;
    }
    else{
    return $this->hunger = 100;
  }
 }
}
$wolf1= new Wolf();
$wolf1->go();
VarDumper::dump($wolf1,10,true);
$wolf1->addPaws();
VarDumper::dump($wolf1,10,true);
$wolf1->eat();
VarDumper::dump($wolf1,10,true);
$wolf1->eat();
$wolf1->eat();
VarDumper::dump($wolf1,10,true);
$wolf1->say('AWOOoooo');
VarDumper::dump($wolf1,10,true);
$wolf1->jump();
VarDumper::dump($wolf1,10,true);
$wolf1->fall();
VarDumper::dump($wolf1,10,true);
$wolf2 = new Wolf();
VarDumper::dump($wolf2,10,true);
?>
